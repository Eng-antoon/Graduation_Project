# importing libraries
import cv2
import numpy as np

#LETTER_A:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter A - The Alphabet for Kids _ Kids Learning Videos.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()


#LETTER_B:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter B - Learning the Alphabet for Kids.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_C:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter C - Learning the ABCs for Kids.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_D:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter D - The Alphabet for Children.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_E:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter E - Learning the ABCs for Kids.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_F:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter F - The ABCs for Children and Toddlers.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_G:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter G - Learning the Letters for Babies and Kids.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_H:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter H - Letters for Children and Toddlers.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_I:qq
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter I - Alphabet Letters for Kids.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_J:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter J - The Alphabet Letters for Kids.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_K:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter K - Things that start with the letter K.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_L:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter L - Things that start with the Letter L.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_M:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter M - The Alphabet for Kids.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_N:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter N - Learning the ABCs for Kids and Preschoolers.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_O:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter O - The Alphabet and ABCs for Children, Kids & Toddlers.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_P:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter P - Things that start with the Letter P.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_Q:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter Q - Learn the Letters of the Alphabet.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_R:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter R - ABCs for Babies and Kids.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_S:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter S - Words that start with S.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_T:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter T - Letters in the Alphabet_ Words that start with T.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_U:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter U - Learning the Alphabet for Kids.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_V:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter V - ABCs for Kids, learn the letters.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_W:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter W - Things that start with the Letter W.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_X:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter X - The Alphabet for Kids and Children.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_Y:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter Y - Learning the ABCs for Kids and Preschoolers.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

#LETTER_Z:
# Create a VideoCapture object and read from input file
cap = cv2.VideoCapture("Letter Z - Words that Start with Z, Learn the ABCs.mp4")

# Check if camera opened successfully
if (cap.isOpened() == False):
    print("Error opening video  file")

# Read until video is completed
while (cap.isOpened()):

    # Capture frame-by-frame
    ret, frame = cap.read()
    if ret == True:
        imS = cv2.resize(frame, (960, 540))  # Resize image
        # Display the resulting frame
        cv2.imshow('Frame', imS)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # Break the loop
    else:
        break

# When everything done, release
# the video capture object
cap.release()

# Closes all the frames
cv2.destroyAllWindows()

