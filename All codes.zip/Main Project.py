import sys
import Motor
from gtts import gTTS
import os
import pygame
import spacy
import time
import testpy
from Motor import GPIO


def start_project():
    import testpy

def start_game():
    myText = f"We are glad you are happy ,So we will start our main program. "
    language = "en"
    output = gTTS(text=myText, lang=language, slow=False)
    output.save("audio/file.mp3")
    pygame.mixer.init()
    pygame.mixer.music.load("audio/file.mp3")
    pygame.mixer.music.play()
    time.sleep(5)

    import SpinGame


def start_alphabet():
    myText = f"Lets learn some english"
    language = "en"
    output = gTTS(text=myText, lang=language, slow=False)
    output.save("audio/file1.mp3")
    pygame.mixer.init()
    pygame.mixer.music.load("audio/file1.mp3")
    pygame.mixer.music.play()
    time.sleep(5)

    import Alphabets

def start_colors():
    myText = f"lets learn about the colors "
    language = "en"
    output = gTTS(text=myText, lang=language, slow=False)
    output.save("audio/file2.mp3")
    pygame.mixer.init()
    pygame.mixer.music.load("audio/file2.mp3")
    pygame.mixer.music.play()
    time.sleep(5)

    import Colours


def start_numbers():
    myText = f"Lets learn about the numbers, its really amazing "
    language = "en"
    output = gTTS(text=myText, lang=language, slow=False)
    output.save("audio/file3.mp3")
    pygame.mixer.init()
    pygame.mixer.music.load("audio/file3.mp3")
    pygame.mixer.music.play()
    time.sleep(5)

    import numbers

def start_paint():
    myText = f"Lets paint with our hands, it can be extraordinary"
    language = "en"
    output = gTTS(text=myText, lang=language, slow=False)
    output.save("audio/file4.mp3")
    pygame.mixer.init()
    pygame.mixer.music.load("audio/file4.mp3")
    pygame.mixer.music.play()
    time.sleep(5)

    import Virtual_Paint.Paint


while(True):

    start_project()

    max_value = max(testpy.counter)
    max_index = testpy.counter.index(max_value)

    if max_index == 0:

        start_game()

        time.sleep(3)

        start_alphabet()

        time.sleep(3)

        start_numbers()

        time.sleep(3)

        start_colors()

        time.sleep(3)

        start_paint()


        ######### start learn program

    elif max_index == 1:
        myText = f"Please try to be active with us, do you want to play a game or learn with us? "
        language = "en"
        output = gTTS(text=myText, lang=language, slow=False)
        output.save("audio/file5.mp3")
        pygame.mixer.init()
        pygame.mixer.music.load("audio/file5.mp3")
        pygame.mixer.music.play()
        time.sleep(5)


        #start_game()
        time.sleep(20)
